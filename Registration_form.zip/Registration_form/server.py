import random
from flask import Flask, render_template, request, redirect, session, flash
app = Flask(__name__)
app.secret_key ="sKey"
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/process', methods=['POST'])
def process():
    counter = 0
    email = str(request.form['email'])
    fName = str(request.form['fName'])
    lName = str(request.form["lName"])
    pw = str(request.form["pw"])
    confirmpw = str(request.form["confirmpw"])
    if not EMAIL_REGEX.match(email):
        flash('E-mail must be a valid email')
    else:
        counter+=1
    if len(fName) < 1 or len(email) < 1 or len(lName) < 1:
        flash('All fields are required and must not be blank')
    else:
        counter+=1
    if fName.isalpha() == False:
        flash('Name should only contain letters')
    else:
        counter+=1
    if len(pw) < 8 or len(confirmpw) < 8:
        flash('Password must contain at least 8 characters')
    else:
        counter+=1
    if pw != confirmpw:
        flash('Password and password confirmation must match')
    else:
        counter+=1
    if counter == 5:
        flash('Thanks for submitting your information')
    print pw
    print confirmpw

    return render_template('index.html',)
app.run(debug=True)